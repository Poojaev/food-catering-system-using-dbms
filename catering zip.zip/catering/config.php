<?php
$conn= mysqli_connect('localhost','root','','catering');
if(!$conn){
	die("database connection failed");
}
?>