
  <?php
        $con = mysqli_connect('localhost', 'root', '', 'catering');
            if (!$con) {
                die("database connection failed");
            }
        ?>
