<?php


$keyId = "rzp_test_3vdBFUcp5BWWsl";
$keySecret ="zLM1dJS2yM3i8qQp7BbeC6MA";
$displayCurrency = 'INR';
error_reporting(E_ALL);
ini_set('display_errors', 1);
