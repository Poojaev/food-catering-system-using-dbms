<?php
require_once 'dbconfig.php';
session_start();
$id=$_SESSION['id'];
class STUDENT {

	private $conn;

	public function __construct() {
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
	}

	public function runQuery( $sql ) {
		$stmt = $this->conn->prepare( $sql );
		return $stmt;
	}

	public function lasdID() {
		$stmt = $this->conn->lastInsertId();
		return $stmt;
	}


	public function razorPayOnline($student_id,$email,$phone, $toValue, $message,$razorpayOrderId,$razorpayPaymentId,$paymentStatus,$makerstamp,$updatestamp,$fee_type) {
		try {
			$stmt = $this->conn->prepare( "INSERT INTO onlinepayment(id,email, phone, toValue, message, razorpayOrderId, razorpayPaymentId, paymentStatus,makerstamp,updatestamp,type) 	
			VALUES(id_o,:email_o,:phone_o,:toValue_o,:message_o,:razorpayOrderId_o,:razorpayPaymentId_o,:paymentStatus_o,:makerstamp_o,:updatestamp_o)" );
			//$stmt->bindparam( ":name_o", $name );
			$stmt->bindparam( ":id_o", $id );
  			$stmt->bindparam( ":email_o", $email );
  			$stmt->bindparam( ":phone_o", $phone );
  			//$stmt->bindparam( ":service_o", $service );
  			//$stmt->bindparam( ":typeProduct_o", $typeProduct ); 
			$stmt->bindparam( ":toValue_o", $toValue ); 
			$stmt->bindparam( ":message_o", $message );
			$stmt->bindparam( ":razorpayOrderId_o", $razorpayOrderId );
			$stmt->bindparam( ":razorpayPaymentId_o", $razorpayPaymentId );
			$stmt->bindparam( ":paymentStatus_o", $paymentStatus );
			$stmt->bindparam( ":makerstamp_o", $makerstamp );
			$stmt->bindparam( ":updatestamp_o", $updatestamp );
			//$stmt->bindparam( ":type_o", $fee_type);
			$stmt->execute();
			return $stmt;

		} catch ( PDOException $ex ) {
			echo $ex->getMessage();
		}
	}
	
	// ...

public function updatePayStatus($email, $razorpayOrderId, $razorpayPaymentId, $paymentStatus, $updatestamp,) {
    try {
        $stmt = $this->conn->prepare( "UPDATE onlinepayment SET razorpayPaymentId=:razorpayPaymentId,paymentStatus=:paymentStatus,updatestamp=:updatestamp WHERE email=:email and razorpayOrderId=:razorpayOrderId");
        $stmt->bindparam( ":email", $email );
        $stmt->bindparam( ":razorpayPaymentId", $razorpayPaymentId );
        $stmt->bindparam( ":paymentStatus", $paymentStatus );
        $stmt->bindparam( ":updatestamp", $updatestamp );
        $stmt->bindparam( ":razorpayOrderId", $razorpayOrderId );
        $stmt->execute();

        // Check if the payment is successful and the type is 'course_fee'
        if ($paymentStatus == 'SUCCESS' && $fee_type == 'course_fees') {
            // Retrieve the course IDs from the session variable
           // $course_ids = $_SESSION['course_ids'];
			$student_id=$_SESSION['id'];

            // Insert the enrollment details into the enrollment table
            foreach ($course_ids as $course_id) {
                //$enrollment_stmt = $this->conn->prepare("INSERT INTO enrollment (student_id, course_id, order_id) VALUES (:student_id, :course_id, :order_id)");
				$enrollment_stmt->bindParam(":id", $id);
                //$enrollment_stmt->bindParam(":course_id", $course_id);
                $enrollment_stmt->bindParam(":order_id", $razorpayOrderId);
				$enrollment_stmt->execute();
				$cart_stmt = $this->conn->prepare("DELETE FROM cart WHERE  id=:id");
                $cart_stmt->bindParam(":id", $id);
                //$cart_stmt->bindParam(":course_id", $course_id);
				$cart_stmt->execute();
               
            }
			
        }

        return $stmt;
		
    } catch (PDOException $ex) {
        echo $ex->getMessage();
    }
}

}